// FUNCION PARA INICIALIZAR TODOS LOS OTROS GRAFICOS
function iniciar1() {
    iniciar1_3();
    iniciar1_4();
    iniciar1_5();
    iniciar1_6();
    iniciar1_7();
    iniciar1_8();
}

// FUNCION PARA ACTUALIZAR TODOS LOS GRAFICOS
function actualizarGraficos() {
    actualizarGrafico1_3();
    actualizarGrafico1_4();
    actualizarGrafico1_5();
    actualizarGrafico1_6();
    actualizarGrafico1_7();
    actualizarGrafico1_8();
}